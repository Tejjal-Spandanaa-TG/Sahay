"use client"

import { MessageCircle, Heart, Phone, Play, Pause, Music } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useState, useRef, useEffect } from "react"

export default function SahayApp() {
  const [currentView, setCurrentView] = useState("home")
  const [chatMessages, setChatMessages] = useState([
    { type: "ai", message: "Hello! I'm here to listen and support you. How are you feeling today?" },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isPlaying, setIsPlaying] = useState(null)
  const [isMusicPlaying, setIsMusicPlaying] = useState(null)
  const audioRef = useRef(null)

  const aiResponses = [
    "I hear you. It must feel overwhelming. Want to try a short breathing exercise?",
    "That sounds really challenging. Remember, it's okay to feel this way. You're not alone.",
    "Thank you for sharing that with me. Your feelings are valid. Would you like to explore some coping strategies?",
    "I understand this is difficult. Taking one step at a time can help. What feels most manageable right now?",
  ]

  const mindfulExercises = [
    {
      title: "5-Min Breathing",
      description: "Simple breathing exercise to calm your mind",
      duration: "5 minutes",
      audioUrl: "/audio/calm-breathing.mp3",
    },
    {
      title: "Exam Stress Relief",
      description: "Guided meditation for academic pressure",
      duration: "8 minutes",
      audioUrl: "/audio/stress-relief.mp3",
    },
    {
      title: "Evening Calm",
      description: "Peaceful sounds to help you unwind",
      duration: "10 minutes",
      audioUrl: "/audio/evening-calm.mp3",
    },
  ]

  const helpResources = [
    {
      name: "AASRA Helpline",
      description: "24/7 suicide prevention helpline",
      contact: "91-22-27546669",
      type: "phone",
    },
    {
      name: "iCALL",
      description: "Psychosocial helpline service",
      contact: "www.icallhelpline.org",
      type: "website",
    },
    {
      name: "Snehi NGO",
      description: "Crisis intervention and emotional support",
      contact: "91-9582208181",
      type: "phone",
    },
  ]

  const sendMessage = () => {
    if (!inputMessage.trim()) return

    const newMessages = [
      ...chatMessages,
      { type: "user", message: inputMessage },
      { type: "ai", message: aiResponses[Math.floor(Math.random() * aiResponses.length)] },
    ]
    setChatMessages(newMessages)
    setInputMessage("")
  }

  const togglePlay = (index) => {
    setIsPlaying(isPlaying === index ? null : index)
  }

  const toggleMusic = async (index) => {
    if (isMusicPlaying === index) {
      setIsMusicPlaying(null)
      if (audioRef.current) {
        audioRef.current.pause()
      }
    } else {
      setIsMusicPlaying(index)
      if (audioRef.current) {
        audioRef.current.src = mindfulExercises[index].audioUrl
        try {
          await audioRef.current.load()
          await audioRef.current.play()
        } catch (error) {
          console.log("[v0] Audio playback failed:", error)
          setIsMusicPlaying(null)
        }
      }
    }
  }

  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
      }
    }
  }, [])

  if (currentView === "chat") {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <Button variant="ghost" size="sm" onClick={() => setCurrentView("home")} className="text-muted-foreground">
              ← Back
            </Button>
            <h1 className="text-xl font-semibold text-foreground">Your Companion</h1>
          </div>

          <div className="space-y-4 mb-6 max-h-96 overflow-y-auto">
            {chatMessages.map((msg, index) => (
              <div key={index} className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}>
                <div
                  className={`max-w-xs p-3 rounded-lg ${
                    msg.type === "user" ? "bg-primary text-primary-foreground" : "bg-card text-card-foreground"
                  }`}
                >
                  <p className="text-sm leading-relaxed">{msg.message}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <Input
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Share what's on your mind..."
              onKeyPress={(e) => e.key === "Enter" && sendMessage()}
              className="flex-1"
            />
            <Button onClick={sendMessage} size="sm">
              Send
            </Button>
          </div>
        </div>
      </div>
    )
  }

  if (currentView === "mindful") {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <Button variant="ghost" size="sm" onClick={() => setCurrentView("home")} className="text-muted-foreground">
              ← Back
            </Button>
            <h1 className="text-xl font-semibold text-foreground">Mindful Moments</h1>
          </div>

          <div className="space-y-4">
            {mindfulExercises.map((exercise, index) => (
              <Card key={index} className="border-border">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-lg text-card-foreground">{exercise.title}</CardTitle>
                      <CardDescription className="text-sm text-muted-foreground">
                        {exercise.description}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toggleMusic(index)}
                        className="bg-transparent border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                      >
                        <Music className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => togglePlay(index)}
                        className="bg-secondary text-secondary-foreground"
                      >
                        {isPlaying === index ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-xs text-muted-foreground">{exercise.duration}</p>
                  {(isPlaying === index || isMusicPlaying === index) && (
                    <div className="mt-3 p-3 bg-accent/20 rounded-md">
                      <p className="text-sm text-accent-foreground">
                        {isMusicPlaying === index && "🎵 Soothing music playing..."}
                        {isPlaying === index && "▶️ Exercise: " + exercise.title + "..."}
                        <br />
                        <span className="text-xs">Close your eyes and focus on your breathing.</span>
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
          <audio ref={audioRef} loop></audio>
        </div>
      </div>
    )
  }

  if (currentView === "help") {
    return (
      <div className="min-h-screen bg-background p-4">
        <div className="max-w-md mx-auto">
          <div className="flex items-center gap-3 mb-6">
            <Button variant="ghost" size="sm" onClick={() => setCurrentView("home")} className="text-muted-foreground">
              ← Back
            </Button>
            <h1 className="text-xl font-semibold text-foreground">Find Help</h1>
          </div>

          <div className="space-y-4">
            {helpResources.map((resource, index) => (
              <Card key={index} className="border-border">
                <CardHeader>
                  <CardTitle className="text-lg text-card-foreground flex items-center gap-2">
                    <Phone className="w-5 h-5 text-primary" />
                    {resource.name}
                  </CardTitle>
                  <CardDescription className="text-muted-foreground">{resource.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button
                    variant="outline"
                    className="w-full text-primary border-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                    onClick={() => {
                      if (resource.type === "phone") {
                        window.open(`tel:${resource.contact}`)
                      } else {
                        window.open(`https://${resource.contact}`, "_blank")
                      }
                    }}
                  >
                    {resource.contact}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-md mx-auto p-6">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground text-balance">Sahay</h1>
          <p className="text-muted-foreground text-sm mt-2 text-pretty">Your Confidential AI Wellness Companion</p>
        </div>

        {/* Main Navigation */}
        <div className="space-y-4">
          <Button
            onClick={() => setCurrentView("chat")}
            className="w-full h-16 bg-primary text-primary-foreground hover:bg-primary/90 flex items-center gap-4 text-left"
          >
            <MessageCircle className="w-6 h-6" />
            <div>
              <div className="font-medium">Chat</div>
              <div className="text-xs opacity-90">Talk to your AI companion</div>
            </div>
          </Button>

          <Button
            onClick={() => setCurrentView("mindful")}
            variant="secondary"
            className="w-full h-16 bg-secondary text-secondary-foreground hover:bg-secondary/90 flex items-center gap-4 text-left"
          >
            <Heart className="w-6 h-6" />
            <div>
              <div className="font-medium">Mindful Moments</div>
              <div className="text-xs opacity-90">Guided exercises and meditation</div>
            </div>
          </Button>

          <Button
            onClick={() => setCurrentView("help")}
            variant="outline"
            className="w-full h-16 border-border text-foreground hover:bg-accent hover:text-accent-foreground flex items-center gap-4 text-left"
          >
            <Phone className="w-6 h-6" />
            <div>
              <div className="font-medium">Find Help</div>
              <div className="text-xs opacity-70">Professional support resources</div>
            </div>
          </Button>
        </div>

        {/* Footer */}
        <div className="mt-12 text-center">
          <p className="text-xs text-muted-foreground text-pretty">
            Remember: You are not alone. Your mental health matters, and seeking help is a sign of strength.
          </p>
        </div>
      </div>
    </div>
  )
}
